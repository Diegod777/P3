from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
# Create your views here.

def Inicio(request):
    return render(request, 'Inicio.html')

def Informacion(request):
    return render(request, 'Informacion.html')

def Registro(request):
    return render(request, 'Registro.html')

def Conocenos(request):
    return render(request, 'Conocenos.html')

def Catalogo(request):
    return render(request, 'Catalogo.html')