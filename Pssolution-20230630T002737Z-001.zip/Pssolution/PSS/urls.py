from django.contrib import admin
from django.urls import path, include
from .views import  Inicio,Conocenos,Informacion,Registro,Catalogo

urlpatterns=[
    path('',Inicio,name="Inicio"),
    path('Conocenos',Conocenos, name="Conocenos"),
    path('Informacion',Informacion, name="Informacion"),
    path('Registro',Registro, name="Registro"),
    path('Catalogo',Catalogo, name="Catalogo"),
    
]